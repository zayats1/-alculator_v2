package fakemain;
public class FakeMainClass {
    public static void main(String[] args) {
        sample.Main.main(args);
    }
}
